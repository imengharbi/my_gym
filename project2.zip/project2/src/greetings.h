void sayHello(char name[],char Hello[]);
