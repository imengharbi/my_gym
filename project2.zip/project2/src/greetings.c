#include <string.h>
#include "greetings.h"
void sayHello(char name[],char hello[]){
strcpy(hello,"Hello ");
strcat(hello,name);
}
